﻿import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToTeaPowderBo;
import pojo.FromToTeaPowderPojo;

@WebServlet("/FromToTeaPowderView")
public class FromToTeaPowderView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToTeaPowderBo teaPowderBo = new FromToTeaPowderBo();
		
		try {
			List<FromToTeaPowderPojo> teaPowderDetails = teaPowderBo.getTeaPowderDetailsView();
			session.setAttribute("teaPowderDetails",teaPowderDetails);
			request.getRequestDispatcher("/TeaPowderViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}