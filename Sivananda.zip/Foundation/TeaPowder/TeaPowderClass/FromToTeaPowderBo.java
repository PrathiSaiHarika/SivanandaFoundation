package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToTeaPowderDao;
import pojo.FromToTeaPowderPojo;

public class FromToTeaPowderBo {
	
	public List<FromToTeaPowderPojo> getTeaPowderDetails(String fromDate, String toDate) throws SQLException{
		FromToTeaPowderDao teaPowderDao = new FromToTeaPowderDao();
		return teaPowderDao.getTeaPowderDetails(fromDate, toDate);
	}
 
	public boolean setTeaPowderDetails(FromToTeaPowderPojo teaPowderPojo) throws SQLException{
		FromToTeaPowderDao teaPowderDao = new FromToTeaPowderDao();
		return teaPowderDao.setTeaPowderDetails(TeaPowderPojo);
	}
	
	/*
	public boolean updateTeaPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToTeaPowderDao teaPowderDao = new FromToTeaPowderDao();
		return teaPowderDao.updateTeaPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteTeaPowderDetails(String date) throws SQLException{
		FromToTeaPowderDao teaPowderDao = new FromToTeaPowderDao();
		return teaPowderDao.deletTeaPowderDetails(date);
	}
	
}