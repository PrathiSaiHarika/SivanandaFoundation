package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToCoconutOilDao;
import pojo.FromToCoconutOilPojo;

public class FromToCoconutOilBo {
	
	public List<FromToCoconutOilPojo> getCoconutOilDetails(String fromDate, String toDate) throws SQLException{
		FromToCoconutOilDao coconutOilDao = new FromToCoconutOilDao();
		return coconutOilDao.getcoconutOilDetails(fromDate, toDate);
	}
 
	public boolean setCoconutOilDetails(FromToCoconutOilPojo CoconutOilPojo) throws SQLException{
		FromToCoconutOilDao coconutOilDao = new FromToCoconutOilDao();
		return coconutOilDao.setCoconutOilDetails(CoconutOilPojo);
	}
	
	/*
	public boolean updateCoconutOilDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToCoconutOilDao coconutOilDao = new FromToCoconutOilDao();
		return coconutOilDao.updateCoconutOilDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteCoconutOilDetails(String date) throws SQLException{
		FromToCoconutOilDao moconutOilDao = new FromToCoconutOilDao();
		return coconutOilDao.deleteCoconutOilDetails(date);
	}
	
}