﻿import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToCoconutOilBo;
import pojo.FromToCoconutOilPojo;

@WebServlet("/FromToCoconutOilView")
public class FromToCoconutOilView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToCoconutOilBo coconutOilBo = new FromToCoconutOilBo();
		
		try {
			List<FromToCoconutOilPojo> coconutOilDetails = coconutOilBo.getCoconutOilDetailsView();
			session.setAttribute("coconutOilDetails",coconutOilxDetails);
			request.getRequestDispatcher("/CoconutOilViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}