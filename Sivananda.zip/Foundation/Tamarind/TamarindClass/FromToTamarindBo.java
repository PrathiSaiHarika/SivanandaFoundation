package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToTamarindDao;
import pojo.FromToTamarindPojo;

public class FromToTamarindBo {
	
	public List<FromToTamarindPojo> getTamarindDetails(String fromDate, String toDate) throws SQLException{
		FromToTamarindDao tamarindDao = new FromToTamarindDao();
		return tamarindDao.gettamarindDetails(fromDate, toDate);
	}
 
	public boolean setTamarindDetails(FromToTamarindPojo TamarindPojo) throws SQLException{
		FromToTamarindDao tamarindDao = new FromToTamarindDao();
		return tamarindDao.setTamarindDetails(TamarindPojo);
	}
	
	/*
	public boolean updateTamarindDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToTamarindDao tamarindDao = new FromToTamarindDao();
		return tamarindDao.updateTamarindDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteTamarindDetails(String date) throws SQLException{
		FromToTamarindDao tamarindDao = new FromToTamarindDao();
		return tamarindDao.deleteTamarindDetails(date);
	}
	
}