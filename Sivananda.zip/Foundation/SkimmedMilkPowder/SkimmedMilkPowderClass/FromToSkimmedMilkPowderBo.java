package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToMilkPowderDao;
import pojo.FromToSkimmedMilkPowderPojo;

public class FromToSkimmedMilkPowderBo {
	
        public List<FromToSkimmedMilkPowderPojo> getSkimmedMilkPowderDetailsView() throws SQLException{
		FromToSkimmedMilkPowderDao skimmedMilkPowderDao = new FromToSkimmedMilkPowderDao();
		return skimmedMilkPowderDao.getSkimmedMilkPowderDetailsView();
	}

	public List<FromToSkimmedMilkPowderPojo> getSkimmedMilkPowderDetails(String fromDate, String toDate) throws SQLException{
		FromToSkimmedMilkPowderDao skimmedMilkPowderDao = new FromToSkimmedMilkPowderDao();
		return skimmedMilkPowderDao.getSkimmedMilkPowderDetails(fromDate, toDate);
	}
 
	public boolean setSkimmedMilkPowderDetails(FromToSkimmedMilkPowderPojo skimmedMilkPowderPojo) throws SQLException{
		FromToSkimmedMilkPowderDao skimmedMilkPowderDao = new FromToSkimmedMilkPowderDao();
		return skimmedMilkPowderDao.setSkimmedMilkPowderDetails(skimmedMilkPowderPojo);
	}
	
	/*
	public boolean updateSkimmedMilkPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToSkimmedMilkPowderDao skimmedMilkPowderDao = new FromToSkimmedMilkPowderDao();
		return skimmedMilkPowderDao.updateMilkPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteSkimmedMilkPowderDetails(String date) throws SQLException{
		FromToSkimmedMilkPowderDao skimmedMilkPowderDao = new FromToSkimmedMilkPowderDao();
		return skimmedMilkPowderDao.deleteSkimmedMilkPowderDetails(date);
	}
	
}