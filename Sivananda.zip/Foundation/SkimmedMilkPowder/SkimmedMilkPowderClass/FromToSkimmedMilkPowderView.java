﻿import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToSkimmedMilkPowderBo;
import pojo.FromToSkimmedMilkPowderPojo;

@WebServlet("/FromToSkimmedMilkPowderView")
public class FromToSkimmedMilkPowderView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToSkimmedMilkPowderBo skimmedMilkPowderBo = new FromToSkimmedMilkPowderBo();
		
		try {
			List<FromToSkimmedMilkPowderPojo> skimmedMilkPowderDetails = skimmedMilkPowderBo.getSkimmedMilkPowderDetailsView();
			session.setAttribute("skimmedMilkPowderDetails",skimmedMilkPowderDetails);
			request.getRequestDispatcher("/SkimmedMilkPowderViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}
