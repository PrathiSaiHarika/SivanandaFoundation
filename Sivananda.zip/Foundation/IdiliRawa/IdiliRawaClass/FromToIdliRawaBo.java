package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToIdliRawaDao;
import pojo.FromToIdliRawaPojo;

public class FromToIdliRawaBo {
	
        public List<FromToIdliRawaPojo> getDetailsIdliRawaView() throws SQLException{
		FromToIdliRawaDao idliRawaDao = new FromToIdliRawaDao();
		return idliRawaDao.getDetailsIdliRawaView();
	}

	public List<FromToIdliRawaPojo> getDetailsIdliRawa(String fromDate, String toDate) throws SQLException{
		FromToIdliRawaDao idliRawaDao = new FromToIdliRawaDao();
		return idliRawaDao.getDetailsIdliRawa(fromDate, toDate);
	}
 
	public boolean setIdliRawaDetails(FromToIdliRawaPojo idlyRawaPojo) throws SQLException{
		FromToIdliRawaDao idlyRawaDao = new FromToIdlyRawa();
		return idliRawaDao.setIdliRawaDetails(idliRawaPojo);
	}
	
	/*
	public boolean updateIdliRawaDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToIdlyRawaDao idlyRawaDao = new FromToIdlyRawaDao();
		return idlyRawaDao.updateIdlyRawaDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteIdliRawaDetails(String date) throws SQLException{
		FromToIdliRawaDao  idliRawaDao = new FromToIdliRawaDao();
		return idliRawaDao.deleteIdliRawaDetails(date);
	} 
	
}
 