package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToRiceDao;
import pojo.FromToRicePojo;

public class FromToRiceBo {
	
	public List<FromToRicePojo> getRiceDetails(String fromDate, String toDate) throws SQLException{
		FromToRiceDao riceDao = new FromToRiceDao();
		return riceDao.getRiceDetails(fromDate, toDate);
	}
 
	public boolean setRiceDetails(FromToRicePojo ricePojo) throws SQLException{
		FromToRiceDao riceDao = new FromToRiceDao();
		return riceDao.setRiceDetails(ricePojo);
	}
	
	/*
	public boolean updateRiceDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToRiceDao riceDao = new FromToRiceDao();
		return riceDao.updateRiceDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteRiceDetails(String date) throws SQLException{
		FromToRiceDao riceDao = new FromToRiceDao();
		return riceDao.deleteRiceDetails(date);
	}
	
}
