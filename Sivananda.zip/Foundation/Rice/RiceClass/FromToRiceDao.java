package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.FromToRicePojo;
import util.COnnect;

public class FromToRiceDao {

	public List<FromToRicePojo> getRiceDetails(String fromDate, String toDate) throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from Rice where date between '" + fromDate + "' and '" + toDate + "'");
		List<FromToRicePojo> riceDetails = new ArrayList<FromToRicePojo>();
		while (rs.next()) {
			FromToRicePojo temp = new FromToRicePojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

			riceDetails.add(temp);
		}
		return riceDetails;
	}
	
	public boolean setRiceDetails(FromToRicePojo ricePojo) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("insert into Rice values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt.setString(1, ricePojo.getDate());
		pstmt.setString(2, ricePojo.getParticulars());
		pstmt.setString(3, ricePojo.getBill_no());
		pstmt.setDouble(4, ricePojo.getCost());
		pstmt.setDouble(5, ricePojo.getAmount());
		pstmt.setDouble(6, ricePojo.getVat());
		pstmt.setDouble(7, ricePojo.getTotal_amount());
		pstmt.setDouble(8, ricePojo.getReceipt());
		pstmt.setDouble(9, ricePojo.getIssued());
		pstmt.setDouble(10, ricePojo.getBalance());
		pstmt.setString(11, ricePojo.getRemarks());
		
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			return true;
		}
		return false;
	}
	
	/*UPDATE
	public boolean updateRiceDetails(String update, String where, String value1, String value2) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("update trail set ? = ? where ? = ? ");
		pstmt.setString(1, update);
		pstmt.setString(1, value1);
		pstmt.setString(3, where);
		pstmt.setString(2, value2);
		pstmt.executeUpdate();
		int r = pstmt.executeUpdate();
		System.out.println(r);
	    if ( r > 0) {
	    	return true;
	    }
	    return false;
	}
	*/
	
	public boolean deleteRiceDetails(String date) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("DELETE FROM Rice WHERE date = ?");
		pstmt.setString(1, date);
		int rows = pstmt.executeUpdate();
		if ( rows > 0) {
		   return true;
		}
        return false;
	}
	
}
