package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToRiceBo;
import pojo.FromToRicePojo;

@WebServlet("/FromToRiceView")
public class FromToRiceView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session=request.getSession();
		FromToRiceBo riceBo = new FromToRiceBo();
		
		try {
			List<FromToRicePojo> riceDetails = riceBo.getRiceDetailsView();
			
			session.setAttribute("riceDetails",riceDetails);
			request.getRequestDispatcher("/RiceViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}
