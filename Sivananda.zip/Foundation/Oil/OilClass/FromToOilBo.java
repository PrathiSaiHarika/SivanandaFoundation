package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToOilDao;
import pojo.FromToOilPojo;

public class FromToOilBo {
	
	public List<FromToOilPojo> getOilDetails(String fromDate, String toDate) throws SQLException{
		FromToOilDao OilDao = new FromToOilDao();
		return oilDao.getoilDetails(fromDate, toDate);
	}
 
	public boolean setOilDetails(FromToOilPojo oilPojo) throws SQLException{
		FromToOilDao oilDao = new FromToOilDao();
		return oilDao.setOilDetails(RawSaltPojo);
	}
	
	/*
	public boolean updateOilDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToOilDao oilDao = new FromToOilDao();
		return oilDao.updateOilDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteOilDetails(String date) throws SQLException{
		FromToOilDao oilDao = new FromToOilDao();
		return oilDao.deleteOilDetails(date);
	}
	
}