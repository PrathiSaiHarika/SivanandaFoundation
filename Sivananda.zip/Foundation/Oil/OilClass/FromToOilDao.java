package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.FromToOilPojo;
import util.COnnect;

public class FromToOilDao {

	public List<FromToOilPojo> getOilDetails(String fromDate, String toDate) throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from Oil where date between '" + fromDate + "' and '" + toDate + "'");
		List<FromToOilPojo> OilDetails = new ArrayList<FromToOilPojo>();
		while (rs.next()) {
			FromToOilPojo temp = new FromToOilPojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

	                oilDetails.add(temp);
		}
		return OilDetails;
	}
	
	public boolean setOilDetails(FromToOilPojo oilPojo) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("insert into Oil values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt.setString(1, oilPojo.getDate());
		pstmt.setString(2, oilPojo.getParticulars());
		pstmt.setString(3, oilPojo.getBill_no());
		pstmt.setDouble(4, oilPojo.getCost());
		pstmt.setDouble(5, oilPojo.getAmount());
		pstmt.setDouble(6, oilPojo.getVat());
		pstmt.setDouble(7, oilPojo.getTotal_amount());
		pstmt.setDouble(8, oilPojo.getReceipt());
		pstmt.setDouble(9, oilPojo.getIssued());
		pstmt.setDouble(10,oilPojo.getBalance());
		pstmt.setString(11,oilPojo.getRemarks());
		
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			return true;
		}
		return false;
	}
	
	/*UPDATE
	public boolean updateOilDetails(String update, String where, String value1, String value2) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("update trail set ? = ? where ? = ? ");
		pstmt.setString(1, update);
		pstmt.setString(1, value1);
		pstmt.setString(3, where);
		pstmt.setString(2, value2);
		pstmt.executeUpdate();
		int r = pstmt.executeUpdate();
		System.out.println(r);
	    if ( r > 0) {
	    	return true;
	    }
	    return false;
	}
	*/
	
	public boolean deleteOilDetails(String date) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("DELETE FROM Oil WHERE date = ?");
		pstmt.setString(1, date);
		int rows = pstmt.executeUpdate();
		if ( rows > 0) {
		   return true;
		}
        -return false;
	}
	
}
