package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToDettolLiquidDao;
import pojo.FromToDettolLiquidPojo;

public class FromToDettolLiquidBo {
	
	public List<FromToDettolLiquidPojo> getDettolLiquidDetails(String fromDate, String toDate) throws SQLException{
		FromToDettolLiquidDao dettolLiquidDao = new FromToDettolLiquidDao();
		return dettolLiquidDao.getdettolLiquidDetails(fromDate, toDate);
	}
 
	public boolean setDettolLiquidDetails(FromToDettolLiquidPojo DettolLiquidPojo) throws SQLException{
		FromToDettolLiquidDao dettolLiquidDao = new FromToDettolLiquidDao();
		return dettolLiquidDao.setDettolLiquidDetails(DettolLiquidPojo);
	}
	
	/*
	public boolean updateDettolLiquidDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToDettolLiquidDao DettolLiquidDao = new FromToDettolLiquidDao();
		return dettolLiquidDao.updateDettolLiquidDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteDettolLiquidDetails(String date) throws SQLException{
		FromToDettolLiquidDao dettolLiquidDao = new FromToDettolLiquidDao();
		return dettolLiquidDao.deleteDettolLiquidDetails(date);
	}
	
}