﻿import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToDettolLiquidBo;
import pojo.FromToDettolLiquidPojo;

@WebServlet("/FromToDettolLiquidView")
public class FromToDettolLiquidView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToDettolLiquidBo dettolLiquidBo = new FromToDettolLiquidBo();
		
		try {
			List<FromToDettolLiquidPojo> dettolLiquidDetails = dettolLiquidBo.getDettolLiquidDetailsView();
			session.setAttribute("dettolLiquidDetails",dettolLiquidDetails);
			request.getRequestDispatcher("/DettolLiquidViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}
