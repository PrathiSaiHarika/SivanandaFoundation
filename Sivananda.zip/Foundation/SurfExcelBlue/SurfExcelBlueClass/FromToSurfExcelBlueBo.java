package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToSurfExcelBlueDao;
import pojo.FromToSurfExcelBluePojo;

public class FromToSurfExcelBlueBo {
	
	public List<FromToSurfExcelBluePojo> getSurfExcelBlueDetails(String fromDate, String toDate) throws SQLException{
		FromToSurfExcelBlueDao surfExcelBlueDao = new FromToSurfExcelBlueDao();
		return surfExcelBlueDao.getsurfExcelBlueDetails(fromDate, toDate);
	}
 
	public boolean setSurfExcelBlueDetails(FromToSurfExcelBluePojo SurfExcelBluePojo) throws SQLException{
		FromToSurfExcelBlueDao surfExcelBlueDao = new FromToSurfExcelBlueDao();
		return surfExcelBlueDao.setSurfExcelBlueDetails(SurfExcelBluePojo);
	}
	
	/*
	public boolean updateSurfExcelBlueDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToSurfExcelBlueDao surfExcelBlueDao = new FromToSurfExcelBlueDao();
		return surfExcelBlueDao.updateSurfExcelBlueDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteSurfExcelBlueDetails(String date) throws SQLException{
		FromToSurfExcelBlueDao surfExcelBlueDao = new FromToSurfExcelBlueDao();
		return surfExcelBlueDao.deleteSurfExcelBlueDetails(date);
	}
	
}