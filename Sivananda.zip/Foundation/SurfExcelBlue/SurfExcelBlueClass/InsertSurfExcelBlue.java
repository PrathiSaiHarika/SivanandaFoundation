package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bo.FromToSurfExcelBlueBo;
import pojo.FromToSurfExcelBluePojo;

@WebServlet("/InsertSurfExcelBlue")
public class InsertSurfExcelBlue extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String date = request.getParameter("date");
		String particulars = request.getParameter("particulars");
		String bill_no = request.getParameter("bill_no");
		double cost = Double.parseDouble(request.getParameter("cost"));
		double amount = Double.parseDouble(request.getParameter("amount"));
		double vat = Double.parseDouble(request.getParameter("vat"));
		double receipt = Double.parseDouble(request.getParameter("receipt"));
		double issued = Double.parseDouble(request.getParameter("issued"));
		double balance = Double.parseDouble(request.getParameter("balance"));
		String remarks = request.getParameter("remarks");

		
		FromToSurfExcelBluePojo surfExcelBluePojo = new FromToSurfExcelBluePojo(date, particulars, bill_no, cost, amount, vat, receipt, issued, balance, remarks);
		FromToSurfExcelBlueBo surfExcelBlueBo = new FromToSurfExcelBlueBo();
		try {
			if (surfExcelBlueBo.setSurfExcelBlueDetails(SurfExcelBluePojo)) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/FromToSurfExcelBlueYesInserted.html");
		    	dispatcher.forward(request, response);	    		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}