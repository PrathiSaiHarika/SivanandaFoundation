package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToSugarDao;
import pojo.FromToSugarPojo;

public class FromToSugarBo {
	
	public List<FromToSugarPojo> getSugarDetails(String fromDate, String toDate) throws SQLException{
		FromToSugarDao sugarDao = new FromToSugarDao();
		return sugarDao.getSugarDetails(fromDate, toDate);
	}
 
	public boolean setSugarDetails(FromToSugarPojo sugarPojo) throws SQLException{
		FromToSugarDao sugarDao = new FromToSugarDao();
		return sugarDao.setSugarDetails(sugarPojo);
	}
	
	/*
	public boolean updateSugarDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToSugarDao sugarDao = new FromToSugarDao();
		return sugarDao.updateSuagrDetails(update, where, value1, value2);
	}
	 */
	public boolean delete SugarDetails(String date) throws SQLException{
		FromToSugarDao sugarDao = new FromToSugarDao();
		return sugarDao.deleteSugarDetails(date);
	}
	
}
