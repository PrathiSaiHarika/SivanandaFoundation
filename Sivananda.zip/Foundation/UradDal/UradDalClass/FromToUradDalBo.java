package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToUdathDalDao;
import pojo.FromToUdathDalPojo;

public class FromToUdathDalBo {
	
	public List<FromToUdathDalPojo> getUdathDalDetails(String fromDate, String toDate) throws SQLException{
		FromToUdathDalDao udathDalDao = new FromToUdathDalDao();
		return UdathDalDao.getUdathDalDetails(fromDate, toDate);
	}
 
	public boolean setUdathDalDetails(FromToUdathDalPojo UdathDalPojo) throws SQLException{
		FromToUdathDalDao udathDalDao = new FromToUdathDalDao();
		return udathDalDao.setUdathDalDetails(UdathDalPojo);
	}
	
	/*
	public boolean updateUdathDalDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToUdathDalDao udathDalDao = new FromToUdathDalDao();
		return udathDalDao.updateUdathDalDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteUdathDalDetails(String date) throws SQLException{
		FromToUdathDalDao UdathDalDao = new FromToUdathDalDao();
		return udathDalDao.deleteUdathDalDetails(date);
	}
	
}