package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.FromToRedLableTeaPowderPojo;
import util.COnnect;

public class FromToRedLableTeaPowderDao {

        
	public List<FromToRedLableTeaPowderPojo> getRedLableTeaPowderDetailsView() throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from redlabelteapowder");
		List<FromToRedLableTeaPowderPojo> redLableTeaPowderDetails = new ArrayList<FromToRedLableTeaPowderPojo>();
		while (rs.next()) {
			FromToRedLableTeaPowderPojo temp = new FromToRedLableTeaPowderPojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

			redLableTeaPowderDetails.add(temp);
		}
		return redLableTeaPowderDetails;
	}
 
	public List<FromToRedLableTeaPowderPojo> getRedLableTeaPowderDetails(String fromDate, String toDate) throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from redlabelteapowder where date between '" + fromDate + "' and '" + toDate + "'");
		List<FromToRedLableTeaPowderPojo> redLableTeaPowderDetails = new ArrayList<FromToRedLableTeaPowderPojo>();
		while (rs.next()) {
			FromToRedLableTeaPowderPojo temp = new FromToRedLableTeaPowderPojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

			redLableTeaPowderDetails.add(temp);
		}
		return redLableTeaPowderDetails;
	}
	
	public boolean setRedLableTeaPowderDetails(FromToRedLableTeaPowderPojo redLableTeaPowderPojo) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("insert into redlabelteapowder values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt.setString(1, milkPowderPojo.getDate());
		pstmt.setString(2, milkPowderPojo.getParticulars());
		pstmt.setString(3, milkPowderPojo.getBill_no());
		pstmt.setDouble(4, milkPowderPojo.getCost());
		pstmt.setDouble(5, milkPowderPojo.getAmount());
		pstmt.setDouble(6, milkPowderPojo.getVat());
		pstmt.setDouble(7, milkPowderPojo.getTotal_amount());
		pstmt.setDouble(8, milkPowderPojo.getReceipt());
		pstmt.setDouble(9, milkPowderPojo.getIssued());
		pstmt.setDouble(10,milkPowderPojo.getBalance());
		pstmt.setString(11,milkPowderPojo.getRemarks());
		
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			return true;
		}
		return false;
	}
	
	/*UPDATE
	public boolean updateRedLableTeaPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("update trail set ? = ? where ? = ? ");
		pstmt.setString(1, update);
		pstmt.setString(1, value1);
		pstmt.setString(3, where);
		pstmt.setString(2, value2);
		pstmt.executeUpdate();
		int r = pstmt.executeUpdate();
		System.out.println(r);
	    if ( r > 0) {
	    	return true;
	    }
	    return false;
	}
	*/
	
	public boolean deleteRedLableTeaPowderDetails(String date) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("DELETE FROM redlabelteapowder WHERE date = ?");
		pstmt.setString(1, date);
		int rows = pstmt.executeUpdate();
		if ( rows > 0) {
		   return true;
		}
        return false;
	}
	
}
