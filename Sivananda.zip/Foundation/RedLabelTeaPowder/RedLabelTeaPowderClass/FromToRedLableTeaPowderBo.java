package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToRedLableTeaPowderDao;
import pojo.FromToRedLableTeaPowderPojo;

public class FromToRedLableTeaPowderBo {
	
        public List<FromToRedLableTeaPowderPojo> getRedLableTeaPowderDetailsView() throws SQLException{
		FromToRedLableTeaPowderDao redLableTeaPowderDao = new FromToRedLableTeaPowderDao();
		return redLableTeaPowderDao.getRedLableTeaPowderDetailsView();
	}
  
	public List<FromToRedLableTeaPowderPojo> getRedLableTeaPowderDetails(String fromDate, String toDate) throws SQLException{
		FromToRedLableTeaPowderDao redLableTeaPowderDao = new FromToRedLableTeaPowderDao();
		return redLableTeaPowderDao.getRedLableTeaPowderDetails(fromDate, toDate);
	}
 
	public boolean setRedLableTeaPowderDetails(FromToRedLableTeaPowderPojo redLableTeaPowderPojo) throws SQLException{
		FromToRedLableTeaPowderDao redLableTeaPowderDao = new FromToRedLableTeaPowderDao();
		return redLableTeaPowderDao.setRedLableTeaPowderDetails(MilkPowderPojo);
	}
	
	/*
	public boolean updateRedLableTeaPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToRedLableTeaPowderDao redLableTeaPowderDao = new FromToRedLableTeaPowderDao();
		return redLableTeaPowderDao.updateRedLableTeaPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteRedLableTeaPowderDetails(String date) throws SQLException{
		FromToRedLableTeaPowderDao redLableTeaPowderDao = new FromToRedLableTeaPowderDao();
		return redLableTeaPowderDao.deleteRedLableTeaPowderDetails(date);
	}
	
}