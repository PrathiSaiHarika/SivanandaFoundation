package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToRobbinbluePowderDao;
import pojo.FromToRobbinbluePowderPojo;

public class FromToRobbinbluePowderBo {
	
	public List<FromToRobbinbluePowderPojo> getRobbinbluePowderDetails(String fromDate, String toDate) throws SQLException{
		FromToRobbinbluePowderDao robbinbluePowderDao = new FromToRobbinbluePowderDao();
		return milkPowderDao.getmilkPowderDetails(fromDate, toDate);
	}
 
	public boolean setRobbinbluePowderDetails(FromToRobbinbluePowderPojo RobbinbluePowderPojo) throws SQLException{
		FromToRobbinbluePowderDao robbinbluePowderDao = new FromToRobbinbluePowderDao();
		return robbinbluePowderDao.setRobbinbluePowderDetails(RobbinbluePowderPojo);
	}
	
	/*
	public boolean updateRobbinbluePowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToRobbinbluePowderDao robbinbluePowderDao = new FromToRobbinbluePowderDao();
		return robbinbluePowderDao.updateRobbinbluePowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteRobbinbluePowderDetails(String date) throws SQLException{
		FromToRobbinbluePowderDao robbinbluePowderDao = new FromToRobbinbluePowderDao();
		return robbinbluePowderDao.deleteRobbinbluePowderDetails(date);
	}
	
}