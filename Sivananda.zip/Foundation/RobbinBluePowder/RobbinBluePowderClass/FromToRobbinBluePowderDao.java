package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.FromToRobbinbluePowderPojo;
import util.COnnect;

public class FromToRobbinbluePowderDao {

	public List<FromToRobbinbluePowderPojo> getRobbinbluePowderDetails(String fromDate, String toDate) throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from RobbinbluePowder where date between '" + fromDate + "' and '" + toDate + "'");
		List<FromToRobbinbluePowderPojo> robbinbluePowderDetails = new ArrayList<FromToRobbinbluePowderPojo>();
		while (rs.next()) {
			FromToRobbinbluePowderPojo temp = new FromToRobbinbluePowderPojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

			robbinbluePowderDetails.add(temp);
		}
		return RobbinbluePowderDetails;
	}
	
	public boolean setRobbinbluePowderDetails(FromToRobbinbluePowderPojo robbinbluePowderPojo) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("insert into MilkPowder values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt.setString(1, robbinbluePowderPojo.getDate());
		pstmt.setString(2, robbinbluePowderPojo.getParticulars());
		pstmt.setString(3, robbinbluePowderPojo.getBill_no());
		pstmt.setDouble(4, robbinbluePowderPojo.getCost());
		pstmt.setDouble(5, robbinbluePowderPojo.getAmount());
		pstmt.setDouble(6, robbinbluePowderPojo.getVat());
		pstmt.setDouble(7, robbinbluePowderPojo.getTotal_amount());
		pstmt.setDouble(8, robbinbluePowderPojo.getReceipt());
		pstmt.setDouble(9, robbinbluePowderPojo.getIssued());
		pstmt.setDouble(10,robbinbluePowderPojo.getBalance());
		pstmt.setString(11,robbinbluePowderPojo.getRemarks());
		
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			return true;
		}
		return false;
	}
	
	/*UPDATE
	public boolean updateRobbinbluePowderDetails(String update, String where, String value1, String value2) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("update trail set ? = ? where ? = ? ");
		pstmt.setString(1, update);
		pstmt.setString(1, value1);
		pstmt.setString(3, where);
		pstmt.setString(2, value2);
		pstmt.executeUpdate();
		int r = pstmt.executeUpdate();
		System.out.println(r);
	    if ( r > 0) {
	    	return true;
	    }
	    return false;
	}
	*/
	
	public boolean deleteRobbinbluePowderDetails(String date) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("DELETE FROM RobbinbluePowder WHERE date = ?");
		pstmt.setString(1, date);
		int rows = pstmt.executeUpdate();
		if ( rows > 0) {
		   return true;
		}
        return false;
	}
	
}
