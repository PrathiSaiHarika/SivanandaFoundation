package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToMatchBoxesDao;
import pojo.FromToMatchBoxesPojo;

public class FromToMatchBoxesBo {
	
	public List<FromToMatchBoxesPojo> getMatchBoxesDetails(String fromDate, String toDate) throws SQLException{
		FromToMatchBoxesDao matchBoxesDao = new FromToMatchBoxesDao();
		return matchBoxesDao.getmatchBoxesDetails(fromDate, toDate);
	}
 
	public boolean setMatchBoxesDetails(FromToMatchBoxesPojo MatchBoxesPojo) throws SQLException{
		FromToMatchBoxesDao matchBoxesDao = new FromToMatchBoxesDao();
		return matchBoxesDao.setMatchBoxesDetails(MatchBoxesPojo);
	}
	
	/*
	public boolean updateMatchBoxesDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToMatchBoxesDao matchBoxesDao = new FromToMatchBoxesDao();
		return matchBoxesDao.updateMatchBoxesDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteMatchBoxesDetails(String date) throws SQLException{
		FromToMatchBoxesDao matchBoxesDao = new FromToMatchBoxesDao();
		return matchBoxesDao.deleteMatchBoxesDetails(date);
	}
	
}