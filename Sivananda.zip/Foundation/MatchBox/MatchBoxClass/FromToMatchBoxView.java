﻿import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToMatchBoxBo;
import pojo.FromToMatchBoxPojo;

@WebServlet("/FromToMatchBoxView")
public class FromToMatchBoxView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToMatchBoxBo matchBoxBo = new FromToMatchBoxBo();
		
		try {
			List<FromToMatchBoxPojo> matchBoxDetails = matchBoxBo.getMatchBoxDetailsView();
			session.setAttribute("matchBoxDetails",matchBoxDetails);
			request.getRequestDispatcher("/MatchBoxViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}