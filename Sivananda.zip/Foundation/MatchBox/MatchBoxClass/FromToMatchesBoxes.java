package controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToMatchBoxesBo;
import pojo.FromToMatchBoxesPojo;

@WebServlet("/FromToMatchBoxes")
public class FromToMatchBoxes extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		
		HttpSession session=request.getSession();
		FromToMatchBoxesBo matchBoxesBo = new FromToMatchBoxesBo();
		List<Double> amount = new ArrayList<>();
		List<Double> vat = new ArrayList<>();
		List<Double> totalAmount = new ArrayList<>();
		List<Double> receipt = new ArrayList<>();
		List<Double> issued = new ArrayList<>();
		List<Double> balance = new ArrayList<>();
   		double sumAmount = 0;
   		double sumVat = 0;
   		double sumTotalAmount = 0;
   		double sumReceipt = 0;
   		double sumIssued = 0;
   		double sumBalance = 0;
		
		try {
			List<FromToMatchBoxesPojo> matchBoxesDetails = MatchBoxesBo.getMatchBoxesDetails(from, to);
			for(FromToMatchBoxesPojo model : matchBoxesDetails) {
	            amount.add(model.getAmount());
	        }
			/*for(Double model : amount) {
	            System.out.println(model);
	        }*/
			for(FromToMatchBoxesPojo model : matchBoxesDetails) {
	            vat.add(model.getVat());
	        }
			for(FromToMatchBoxesPojo model : matchBoxesDetails) {
	            totalAmount.add(model.getTotal_amount());
	        }
			for(FromToMatchBoxesPojo model : matchBoxesDetails) {
	            receipt.add(model.getReceipt());
	        }
			for(FromToMatchBoxesPojo model : matchBoxesDetails) {
	            issued.add(model.getIssued());
	        }
			for(FromToMatchBoxesPojo model : matchBoxesDetails){
	            balance.add(model.getBalance());
	        }
			for(Double d : amount) {
			    sumAmount += d;
			}
			for(Double d : vat) {
			    sumVat += d;
			}
			for(Double d : totalAmount) {
			    sumTotalAmount += d;
			}
			for(Double d : receipt) {
			    sumReceipt += d;
			}
			for(Double d : issued) {
			    sumIssued += d;
			}
			for(Double d : balance) {
			    sumBalance += d;
			}
			//System.out.println(sumNum1);
			session.setAttribute("sumAmount",sumAmount);
			session.setAttribute("sumVat",sumVat);
			session.setAttribute("sumTotalAmount",sumTotalAmount);
			session.setAttribute("sumReceipt",sumReceipt);
			session.setAttribute("sumIssued",sumIssued);
			session.setAttribute("sumBalance",sumBalance);
			session.setAttribute("matchBoxesDetails",matchBoxesDetails);
			request.getRequestDispatcher("/MatchBoxesView.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}