﻿package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToMuttonDao;
import pojo.FromToMuttonPojo;

public class FromToMuttonBo {
	
	public List<FromToMuttonPojo> getMuttonDetails(String fromDate, String toDate) throws SQLException{
		FromToMuttonDao muttonDao = new FromToMuttonDao();
		return muttonDao.getmuttonDetails(fromDate, toDate);
	}
 
	public boolean setMuttonDetails(FromToMuttonPojo muttonPojo) throws SQLException{
		FromToMuttonDao muttonDao = new FromToMuttonDao();
		return muttonDao.setMuttonDetails(muttonPojo);
	}
	
	/*
	public boolean updateMuttonDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToMuttonDao muttonDao = new FromToMuttonDao();
		return muttonDao.updateMuttonDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteMuttonDetails(String date) throws SQLException{
		FromToMuttonDao muttonDao = new FromToMuttonDao();
		return muttonDao.deleteMuttonDetails(date);
	}
	
}