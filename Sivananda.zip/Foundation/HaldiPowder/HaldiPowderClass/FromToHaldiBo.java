package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToHaldiDao;
import pojo.FromToHaldiPojo;

public class FromToHaldiBo {
	
	public List<FromToHaldiPojo> getHaldiDetails(String fromDate, String toDate) throws SQLException{
		FromToHaldiDao haldiDao = new FromToHaldiDao();
		return matchBoxesDao.getmatchBoxesDetails(fromDate, toDate);
	}
 
	public boolean setHaldiDetails(FromToHaldiPojo haldiPojo) throws SQLException{
		FromToHaldiDao haldiDao = new FromToHaldiDao();
		return haldiDao.setHaldiDetails(HaldiPojo);
	}
	
	/*
	public boolean updateHaldiDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToHaldiDao haldiDao = new FromToHaldiDao();
		return haldiDao.updateHaldiDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteHaldiDetails(String date) throws SQLException{
		FromToHaldiDao haldiDao = new FromToHaldiDao();
		return haldiDao.deleteHaldiDetails(date);
	}
	
}