package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToRawSaltDao;
import pojo.FromToRawSaltPojo;

public class FromToRawSaltBo {
	
	public List<FromToRawSaltPojo> getRawSaltDetails(String fromDate, String toDate) throws SQLException{
		FromToRawSaltDao rawSaltDao = new FromToRawSaltDao();
		return rawSaltDao.getrawSaltDetails(fromDate, toDate);
	}
 
	public boolean setRawSaltDetails(FromToRawSaltPojo rawSaltPojo) throws SQLException{
		FromToRawSaltDao rawSaltDao = new FromToRawSaltDao();
		return rawSaltDao.setRawSaltDetails(RawSaltPojo);
	}
	
	/*
	public boolean updateRawSaltDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToRawSaltDao rawSaltDao = new FromToRawSaltDao();
		return rawSaltDao.updateRawSaltDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteRawSaltDetails(String date) throws SQLException{
		FromToRawSaltDao rawSaltDao = new FromToRawSaltDao();
		return rawSaltDao.deleteRawSaltDetails(date);
	}
	
}