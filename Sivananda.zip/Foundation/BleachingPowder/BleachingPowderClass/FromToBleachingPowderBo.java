package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToBleachingPowderDao;
import pojo.FromToBleachingPowderPojo;

public class FromToBleachingPowderBo {
	
	public List<FromToBleachingPowderPojo> getBleachingPowderDetails(String fromDate, String toDate) throws SQLException{
		FromToBleachingPowderDao bleachingPowderDao = new FromToBleachingPowderDao();
		return bleachingPowderDao.getbleachingPowderDetails(fromDate, toDate);
	}
 
	public boolean setBleachingPowderDetails(FromToBleachingPowderPojo BleachingPowderPojo) throws SQLException{
		FromToBleachingPowderDao bleachingPowderDao = new FromToBleachingPowderDao();
		return bleachingPowderDao.setBleachingPowderDetails(BleachingPowderPojo);
	}
	
	/*
	public boolean updateBleachingPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToBleachingPowderDao mleachingPowderDao = new FromToBleachingPowderDao();
		return bleachingPowderDao.updateBleachingPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteBleachingPowderDetails(String date) throws SQLException{
		FromToBleachingPowderDao bleachingPowderDao = new FromToBleachingPowderDao();
		return bleachingPowderDao.deleteBleachingPowderDetails(date);
	}
	
}