﻿import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToBleachingPowderBo;
import pojo.FromToBleachingPowderPojo;

@WebServlet("/FromToBleachingPowderView")
public class FromToBleachingPowderView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToBleachingPowderBo bleachingPowderBo = new FromToBleachingPowderBo();
		
		try {
			List<FromToBleachingPowderPojo> bleachingPowderDetails = bleachingPowderBo.getBleachingPowderDetailsView();
			session.setAttribute("bleachingPowderDetails",bleachingPowderDetails);
			request.getRequestDispatcher("/BleachingPowderViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}
