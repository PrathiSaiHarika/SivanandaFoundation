﻿import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToLuxSoapBo;
import pojo.FromToLuxSoapPojo;

@WebServlet("/FromToLuxSoapView")
public class FromToLuxSoapView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToLuxSoapBo luxSoapBo = new FromToLuxSoapBo();
		
		try {
			List<FromToLuxSoapPojo> luxSoapDetails = luxSoapBo.getLuxSoapDetailsView();
			session.setAttribute("luxSoapDetails",luxSoapDetails);
			request.getRequestDispatcher("/LuxSoapViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}