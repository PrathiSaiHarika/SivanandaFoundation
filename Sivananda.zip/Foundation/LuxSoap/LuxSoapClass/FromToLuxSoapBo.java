package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToLuxSoapDao;
import pojo.FromToLuxSoapPojo;

public class FromToLuxSoapBo {
	
	public List<FromToLuxSoapPojo> getLuxSoapDetails(String fromDate, String toDate) throws SQLException{
		FromToLuxSoapDao luxsoapDao = new FromToLuxSoapDao();
		return luxsoapDao.getLuxSoapDetails(fromDate, toDate);
	}
 
	public boolean setLuxSoapDetails(FromToLuxSoapPojo luxsoapPojo) throws SQLException{
		FromToLuxSoapDao luxsoapDao = new FromToLuxSoapDao();
		return luxsoapDao.setLuxSoapDetails(sugarPojo);
	}
	
	/*
	public boolean updateLuxSoaprDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToLuxSoapDao luxsoapDao = new FromToLuxSoapDao();
		return luxsoapDao.updateLuxSoapDetails(update, where, value1, value2);
	}
	 */
	public boolean delete LuxSoapDetails(String date) throws SQLException{
		FromToLuxSoapDao luxsoapDao = new FromToLuxSoapDao();
		return luxsoapDao.deleteLuxSoapDetails(date);
	}
	
}
