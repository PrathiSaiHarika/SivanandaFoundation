package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToChakkiAttaDao;
import pojo.FromToChakkiAttaPojo;

public class FromToChakkiAttaBo {
	
	public List<FromToChakkiAttaPojo> getChakkiAttaDetails(String fromDate, String toDate) throws SQLException{
		FromToChakkiAttaDao chakkiAttaDao = new FromToChakkiAttaDao();
		return chakkiAttaDao.getChakkiAttaDetails(fromDate, toDate);
	}
 
	public boolean setChakkiAttaDetails(FromToChakkiAttaPojo ChakkiAttaPojo) throws SQLException{
		FromToChakkiAttaDao chakkiAttaDao = new FromToChakkiAttaDao();
		return chakkiAttaDao.setChakkiAttaDetails(MatchBoxesPojo);
	}
	
	/*
	public boolean updateChakkiAttaDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToChakkiAttaDao chakkiAttaDao = new FromToChakkiAttaDao();
		return chakkiAttaDao.updateChakkiAttaDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteChakkiAttaDetails(String date) throws SQLException{
		FromToChakkiAttaDao chakkiAttaDao = new FromToChakkiAttaDao();
		return chakkiAttaDao.deleteChakkiAttaDetails(date);
	}
	
}