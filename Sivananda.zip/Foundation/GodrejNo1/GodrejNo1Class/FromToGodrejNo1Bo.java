package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToGodrejNo1Dao;
import pojo.FromToGodrejNo1Pojo;

public class FromToGodrejNo1Bo {
	
	public List<FromToGodrejNo1Pojo> getGodrejNo1Details(String fromDate, String toDate) throws SQLException{
		FromToGodrejNo1Dao godrejNo1Dao = new FromToGodrejNo1Dao();
		return GodrejNo1Dao.getgodrejNo1Details(fromDate, toDate);
	}
 
	public boolean setGodrejNo1Details(FromToGodrejNo1Pojo GodrejNo1Pojo) throws SQLException{
		FromToGodrejNo1Dao godrejNo1Dao = new FromToGodrejNo1Dao();
		return godrejNo1Dao.setGodrejNo1Details(GodrejNo1Pojo);
	}
	
	/*
	public boolean updateGodrejNo1Details(String update, String where, String value1, String value2) throws SQLException{
		FromToGodrejNo1Dao godrejNo1Dao = new FromToGodrejNo1Dao();
		return godrejNo1Dao.updateGodrejNo1Details(update, where, value1, value2);
	}
	 */
	public boolean deleteGodrejNo1Details(String date) throws SQLException{
		FromToGodrejNo1Dao godrejNo1Dao = new FromToGodrejNo1Dao();
		return godrejNo1Dao.deleteGodrejNo1Details(date);
	}
	
}