﻿import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToGodrejNo1Bo;
import pojo.FromToGodrejNo1Pojo;

@WebServlet("/FromToGodrejNo1View")
public class FromToGodrejNo1View extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToGodrejNo1Bo godrejNo1Bo = new FromToGodrejNo1Bo();
		
		try {
			List<FromToGodrejNo1Pojo> godrejNo1Details = godrejNo1Bo.getGodrejNo1DetailsView();
			session.setAttribute("godrejNo1Details",godrejNo1Details);
			request.getRequestDispatcher("/GodrejNo1ViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}

