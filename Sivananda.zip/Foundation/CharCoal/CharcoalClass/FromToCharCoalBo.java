﻿package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToCharCoalDao;
import pojo.FromToCharCoalPojo;

public class FromToCharCoalBo {
	
	public List<FromToCharCoalPojo> getCharCoalDetails(String fromDate, String toDate) throws SQLException{
		FromToCharCoalDao charCoalDao = new FromToCharCoalDao();
		return charCoalDao.getcharCoalDetails(fromDate, toDate);
	}
 
	public boolean setCharCoalDetails(FromToCharCoalPojo charCoalPojo) throws SQLException{
		FromToCharCoalDao charCoalDao = new FromToCharCoalDao();
		return charCoalDao.setCharCoalDetails(charCoalPojo);
	}
	
	/*
	public boolean updateCharCoalDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToCharCoalDao charCoalDao = new FromToCharCoalDao();
		return charCoalDao.updateCharCoalDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteCharCoalDetails(String date) throws SQLException{
		FromToCharCoalDao charCoalDao = new FromToCharCoalDao();
		return charCoalDao.deleteCharCoalDetails(date);
	}
	
}