﻿package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToDettolSoapDao;
import pojo.FromToDettolSoapPojo;

public class FromToDettolSoapBo {
	
	public List<FromToDettolSoapPojo> getDettolSoapDetails(String fromDate, String toDate) throws SQLException{
		FromToDettolSoapDao dettolSoapDao = new FromToDettolSoapDao();
		return dettolSoapDao.getdettolSoapDetails(fromDate, toDate);
	}
 
	public boolean setDettolSoapDetails(FromToDettolSoapPojo dettolSoapPojo) throws SQLException{
		FromToDettolSoapDao dettolSoapDao = new FromToDettolSoapDao();
		return dettolSoapDao.setDettolSoapDetails(dettolSoapPojo);
	}
	
	/*
	public boolean updateDettolSoapDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToDettolSoapDao dettolSoapDao = new FromToDettolSoapDao();
		return dettolSoapDao.updateDettolSoapDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteDettolSoapDetails(String date) throws SQLException{
		FromToDettolSoapDao dettolSoapDao = new FromToDettolSoapDao();
		return dettolSoapDao.deleteDettolSoapDetails(date);
	}
	
}

