package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bo.FromToWheelSoapsBo;

@WebServlet("/DeleteWheelSoaps")
public class DeleteWheelSoaps extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String date = request.getParameter("date");
		
		FromToWheelSoapBo wheelSoapBo = new FromToWheelSoapBo();
		
		try {
		    if (wheelSoapBo.deleteWheelSoapDetails(date)) {
			    RequestDispatcher dispatcher = request.getRequestDispatcher("/FromToWheelSoapYesDeleted.html");
	    	    dispatcher.forward(request, response);	 
		    }
		} catch (Exception e) {
			e.printStackTrace();
	    }
	}
}
