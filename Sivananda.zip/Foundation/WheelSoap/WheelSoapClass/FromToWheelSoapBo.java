package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToWheelSoapDao;
import pojo.FromToWheelSoapPojo;

public class FromToWheelSoapBo {
	
	public List<FromToWheelSoapPojo> getDetailsWheelSoap(String fromDate, String toDate) throws SQLException{
		FromToWheelSoapDao wheelSoapDao = new FromToWheelSoapDao();
		return wheelSoapDetails(fromDate, toDate);
	}
 
	public boolean setWheelSoapDetails(FromToWheelSoapPojo wheelSoapPojo) throws SQLException{
		FromToWheelSoapDao wheelSoapsDao = new FromToWheelSoap();
		return wheelSoapDao.set WheelSoapDetails(wheelSoapPojo);
	}
	
	/*
	public boolean updateWheelSoapDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToWheelSoapDao = new FromToWheelSoapDao();
		return wheelSoapDao.updateWheelSoapDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteWheelSoapDetails(String date) throws SQLException{
		FromToWheelSoapDao wheelSoapDao = new FromToWheelSoapDao();
		return wheelSoapDao.deleteWheelSoapDetails(date);
	} 
	
}
 