package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToWheatRawaDao;
import pojo.FromToWheatRawaPojo;

public class FromToWheatRawaBo {
	
	public List<FromToWheatRawaPojo> getWheatRawaDetails(String fromDate, String toDate) throws SQLException{
		FromToWheatRawaDao wheatRawaDao = new FromToWheatRawaDao();
		return wheatRawaDao.getwheatRawaDetails(fromDate, toDate);
	}
 
	public boolean setWheatRawaDetails(FromToWheatRawaPojo WheatRawaPojo) throws SQLException{
		FromToWheatRawaDao wheatRawaDao = new FromToWheatRawaDao();
		return wheatRawaDao.setWheatRawaDetails(WheatRawaPojo);
	}
	
	/*
	public boolean updateWheatRawaDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToWheatRawaDao wheatRawaDao = new FromToWheatRawaDao();
		return wheatRawaDao.updateWheatRawaDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteWheatRawaDetails(String date) throws SQLException{
		FromToWheatRawaDao wheatRawaDao = new FromToWheatRawaDao();
		return wheatRawaDao.deleteWheatRawaDetails(date);
	}
	
}