package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToWashingPowderDao;
import pojo.FromToWashingPowderPojo;

public class FromToWashingPowderBo {
	
	public List<FromToWashingPowderPojo> getwashingPowderDetails(String fromDate, String toDate) throws SQLException{
		FromoToWashingPowderDao washingPowderDao = new FromToWashingPowderDao();
		return washingPowderDao.getwashingPowderDetails(fromDate, toDate);
	}
 
	public boolean setwashingPowderDetails(FromToWashingPowderPojo WashingPowderPojo) throws SQLException{
		FromToWashingPowderDao washingPowderDao = new FromToWashingPowderDao();
		return washingPowderDao.setWashingPowderDetails(WashingPowderPojo);
	}
	
	/*
	public boolean updateWashingPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToWashingPowderDao washingPowderDao = new FromToWashingPowderDao();
		return washingPowderDao.updateWashingPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteWashingPowderDetails(String date) throws SQLException{
		FromToWashingPowderDao washingPowderDao = new FromToWashingPowderDao();
		return washingPowderDao.deleteWashingPowderDetails(date);
	}
	
}