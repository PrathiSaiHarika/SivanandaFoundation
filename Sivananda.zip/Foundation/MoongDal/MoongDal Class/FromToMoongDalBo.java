package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToMoongDalDao;
import pojo.FromToMoongDalPojo;

public class FromToMoongDalBo {
	
	public List<FromToMoongDalPojo> getDetails  moongDal(String fromDate, String toDate) throws SQLException{
		FromToMoongDalDao moongDalDao = new FromToMoongDalDao();
		return moongDalDetails(fromDate, toDate);
	}
 
	public boolean setMoongDalDetails(FromToMoongDalPojo moongDalPojo) throws SQLException{
		FromToMoongDalDao mongDalDao = new FromToMoongDal();
		return moongDalDao.setMoongDalDetails(moongDalPojo);
	}
	
	/*
	public boolean updateMoongDalDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToMoongDalDao mongDalDao = new FromToRawSaltDao();
		returnmoongDalDao.updateMoongDalDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteMoongDalDetails(String date) throws SQLException{
		FromToMoongDalDao moongDalDao = new FromToMoongDalDao();
		return moongDalDao.deleteMoongDalDetails(date);
	} 
	
}
 