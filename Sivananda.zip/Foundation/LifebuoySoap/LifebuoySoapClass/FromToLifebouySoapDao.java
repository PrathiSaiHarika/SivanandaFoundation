package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojo.FromToLifebouySoapPojo;
import util.COnnect;

public class FromToLifebouySoapDao {

	public List<FromToLifebouySoapPojo> getLifebouySoapDetails(String fromDate, String toDate) throws SQLException{
		Connection con = COnnect.getConncetion();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from LifebouySoap where date between '" + fromDate + "' and '" + toDate + "'");
		List<FromToLifebouySoapPojo> lifebouySoapDetails = new ArrayList<FromToLifebouySoapPojo>();
		while (rs.next()) {
			FromToLifebouySoapPojo temp = new FromToLifebouySoapPojo();
			temp.setDate(rs.getString(1));
			temp.setParticulars(rs.getString(2));
			temp.setBill_no(rs.getString(3));
			temp.setCost(rs.getDouble(4));
			temp.setAmount(rs.getDouble(5));
			temp.setVat(rs.getDouble(6));
			temp.setTotal_amount(rs.getDouble(7));
			temp.setReceipt(rs.getDouble(8));
			temp.setIssued(rs.getDouble(9));
			temp.setBalance(rs.getDouble(10));
			temp.setRemarks(rs.getString(11));

			LifebouySoapDetails.add(temp);
		}
		return LifebouySoapDetails;
	}
	
	public boolean setLifebouySoapDetails(FromToLifebouySoapPojo lifebouySoapPojo) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("insert into LifebouySoap values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
		
		pstmt.setString(1, lifebouySoapPojo.getDate());
		pstmt.setString(2, lifebouySoapPojo.getParticulars());
		pstmt.setString(3, lifebouySoapPojo.getBill_no());
		pstmt.setDouble(4, lifebouySoapPojo.getCost());
		pstmt.setDouble(5, lifebouySoapPojo.getAmount());
		pstmt.setDouble(6, lifebouySoapPojo.getVat());
		pstmt.setDouble(7, lifebouySoapPojo.getTotal_amount());
		pstmt.setDouble(8, lifebouySoapPojo.getReceipt());
		pstmt.setDouble(9, lifebouySoapPojo.getIssued());
		pstmt.setDouble(10,lifebouySoapPojo.getBalance());
		pstmt.setString(11,lifebouySoapPojo.getRemarks());
		
		int rows = pstmt.executeUpdate();
		if (rows > 0) {
			return true;
		}
		return false;
	}
	
	/*UPDATE
	public boolean updateLifebouySoapDetails(String update, String where, String value1, String value2) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("update trail set ? = ? where ? = ? ");
		pstmt.setString(1, update);
		pstmt.setString(1, value1);
		pstmt.setString(3, where);
		pstmt.setString(2, value2);
		pstmt.executeUpdate();
		int r = pstmt.executeUpdate();
		System.out.println(r);
	    if ( r > 0) {
	    	return true;
	    }
	    return false;
	}
	*/
	
	public boolean deleteLifebouySoapDetails(String date) throws SQLException{
		Connection con = COnnect.getConncetion();
		PreparedStatement pstmt =con.prepareStatement("DELETE FROM LifebouySoap WHERE date = ?");
		pstmt.setString(1, date);
		int rows = pstmt.executeUpdate();
		if ( rows > 0) {
		   return true;
		}
        return false;
	}
	
}
