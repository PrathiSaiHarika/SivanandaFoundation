package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToLifebouySoapDao;
import pojo.FromToLifebouySoapPojo;

public class FromToLifebouySoapBo {
	
	public List<FromToLifebouySoapPojo> getLifebouySoapDetails(String fromDate, String toDate) throws SQLException{
		FromToLifebouySoapDao lifebouySoapDao = new FromToLifebouySoapDao();
		return lifebouySoapDao.getlifebouySoapDetails(fromDate, toDate);
	}
 
	public boolean setLifebouySoapDetails(FromToLifebouySoapPojo LifebouySoapPojo) throws SQLException{
		FromToLifebouySoapDao lifebouySoapDao = new FromToLifebouySoapDao();
		return lifebouySoapDao.setLifebouySoapDetails(LifebouySoapPojo);
	}
	
	/*
	public boolean updateLifebouySoapDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToLifebouySoapDao lifebouySoapDao = new FromToLifebouySoapDao();
		return lifebouySoapDao.updateLifebouySoapDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteLifebouySoapDetails(String date) throws SQLException{
		FromToLifebouySoapDao lifebouySoapDao = new FromToLifebouySoapDao();
		return lifebouySoapDao.deleteLifebouySoapDetails(date);
	}
	
}