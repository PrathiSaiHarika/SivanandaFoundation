package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToHarpicLiquidDao;
import pojo.FromToHarpicLiquidPojo;

public class FromToHarpicLiquidBo {
	
	public List<FromToHarpicLiquidPojo> getHarpicLiquidDetails(String fromDate, String toDate) throws SQLException{
		FromToHarpicLiquidDao harpicLiquidDao = new FromToHarpicLiquidDao();
		return harpicLiquidDao.getharpicLiquidDetails(fromDate, toDate);
	}
 
	public boolean setHarpicLiquidDetails(FromToHarpicLiquidPojo harpicLiquidPojo) throws SQLException{
		FromToHarpicLiquidDao harpicLiquidDao = new FromToHarpicLiquidDao();
		return harpicLiquidDao.setHarpicLiquidDetails(HarpicLiquidPojo);
	}
	
	/*
	public boolean updateHarpicLiquidDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToHarpicLiquidDao harpicLiquidDao = new FromToHarpicLiquidDao();
		return harpicLiquidDao.updateHarpicLiquidDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteHarpicLiquidDetails(String date) throws SQLException{
		FromToHarpicLiquidDao harpicLiquidDao = new FromToHarpicLiquidDao();
		return harpicLiquidDao.deleteHarpicLiquidDetails(date);
	}
	
}