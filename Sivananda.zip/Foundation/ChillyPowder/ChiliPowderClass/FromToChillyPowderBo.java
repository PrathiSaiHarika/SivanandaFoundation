package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToChillyPowderDao;
import pojo.FromToChillyPowderPojo;

public class FromToChillyPowderBo {
	
	public List<FromToChillyPowderPojo> getChillyPowderDetails(String fromDate, String toDate) throws SQLException{
		FromToChillyPowderDao chillyPowderDao = new FromToChillyPowderDao();
		return chillyPowderDao.getchillyPowderDetails(fromDate, toDate);
	}
 
	public boolean setChillyPowderDetails(FromToChillyPowderPojo ChillyPowderPojo) throws SQLException{
		FromToChillyPowderDao chillyPowderDao = new FromToChillyPowderDao();
		return chillyPowderDao.setChillyPowderDetails(chillyPowderPojo);
	}
	
	/*
	public boolean updateChillyPowderDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToChillyPowderDao chillyPowderDao = new FromToChillyPowderDao();
		return chillyPowderDao.updateChillyPowderDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteChillyPowderDetails(String date) throws SQLException{
		FromToChillyPowderDao chillyPowderDao = new FromToChillyPowderDao();
		return chillyPowderDao.deleteChillyPowderDetails(date);
	}
	
}