﻿package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToSodaAshDao;
import pojo.FromToSodaAshPojo;

public class FromToSodaAshBo {
	
	public List<FromToSodaAshPojo> getSodaAshDetails(String fromDate, String toDate) throws SQLException{
		FromToSodaAshDao sodaAshDao = new FromToSodaAshDao();
		return sodaAshDao.getsodaAshDetails(fromDate, toDate);
	}
 
	public boolean setSodaAshDetails(FromToSodaAshPojo sodaAshPojo) throws SQLException{
		FromToSodaAshDao sodaAshDao = new FromToSodaAshDao();
		return sodaAshDao.setSodaAshDetails(sodaAshPojo);
	}
	
	/*
	public boolean updateSodaAshDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToSodaAshDao sodaAshDao = new FromToSodaAshDao();
		return sodaAshDao.updateSodaAshDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteSodaAshDetails(String date) throws SQLException{
		FromToSodaAshDao sodaAshDao = new FromToSodaAshDao();
		return sodaAshDao.deleteSodaAshDetails(date);
	}
	
}