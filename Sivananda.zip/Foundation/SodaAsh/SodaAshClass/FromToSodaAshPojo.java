﻿package pojo;

public class FromToSodaAshPojo {
     String date;
     String particulars;
     String bill_no;
     double cost;
     double amount;
     double vat;
     double total_amount;
     double receipt;
     double issued;
     double balance;
     String remarks;

     
     
     public FromToSodaAshPojo(String date, String particulars, String bill_no, double cost, double amount, double vat,
			 double receipt, double issued, double balance, String remarks) {
		super();
		this.date = date;
		this.particulars = particulars;
		this.bill_no = bill_no;
		this.cost = cost;
		this.amount = amount;
		this.vat = vat;
		this.total_amount = total_amount;
		this.receipt = receipt;
		this.issued = issued;
		this.balance = balance;
		this.remarks = remarks;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getParticulars() {
		return particulars;
	}

	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}

	public String getBill_no() {
		return bill_no;
	}

	public void setBill_no(String bill_no) {
		this.bill_no = bill_no;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getVat() {
		return vat;
	}

	public void setVat(double vat) {
		this.vat = vat;
	}

	public double getTotal_amount() {
		return total_amount = vat * amount;
	}

	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}

	public double getReceipt() {
		return receipt;
	}

	public void setReceipt(double receipt) {
		this.receipt = receipt;
	}

	public double getIssued() {
		return issued;
	}

	public void setIssued(double issued) {
		this.issued = issued;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	
	public FromToSodaAshPojo() {}

		
}