﻿import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bo.FromToSodaAshBo;
import pojo.FromToSodaAshPojo;

@WebServlet("/FromToSodaAshView")
public class FromToSodaAshView extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		FromToSodaAshBo sodaAshBo = new FromToSodaAshBo();
		
		try {
			List<FromToSodaAshPojo> sodaAshDetails = sodaAshBo.getSodaAshDetailsView();
			session.setAttribute("sodaAshDetails",sodaAshDetails);
			request.getRequestDispatcher("/SodaAshViewAll.jsp").forward(request, response);
			
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
}
