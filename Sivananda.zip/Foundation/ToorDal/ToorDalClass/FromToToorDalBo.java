package bo;

import java.sql.SQLException;
import java.util.List;
import dao.FromToToorDalDao;
import pojo.FromToToorDalPojo;

public class FromToToorDalBo {
	
	public List<FromToToorDalPojo> getToorDalDetails(String fromDate, String toDate) throws SQLException{
		FromToToorDalDao toorDalDao = new FromToToorDalDao();
		return toorDalDao.getToorDalDetails(fromDate, toDate);
	}
 
	public boolean setToorDalDetails(FromToToorDalPojo ToorDalPojo) throws SQLException{
		FromToToorDalDao toorDalDao = new FromToToorDalDao();
		return toorDalDao.setToorDalDetails(ToorDalPojo);
	}
	
	/*
	public boolean updateToorDalDetails(String update, String where, String value1, String value2) throws SQLException{
		FromToToorDalDao toorDalDao = new FromToToorDalDao();
		return toorDalDao.updateToorDalDetails(update, where, value1, value2);
	}
	 */
	public boolean deleteToorDalDetails(String date) throws SQLException{
		FromToToorDalDao toorDalDao = new FromToToorDalDao();
		return toorDalDao.deleteToorDalDetails(date);
	}
	
}